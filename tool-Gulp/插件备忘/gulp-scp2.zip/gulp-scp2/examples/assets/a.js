console.log('a.js');
