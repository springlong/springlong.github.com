## 0.2.0 / 2015-06-15

- update readme
- fix windows path #3
- ignore directory fix #1
- remove gulp-util

## 0.1.3

upgrade version

## 0.1.2

keywords

## 0.1.1

Add watch option

## 0.1.0

First version
