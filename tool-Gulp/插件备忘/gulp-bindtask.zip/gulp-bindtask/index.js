'use strict';

// 引入 gulp
var gulp = require('gulp'); 

// 引入组件
var concat = require('gulp-concat'); 			// 合并文件
var rename = require('gulp-rename'); 			// 文件重命名
var replace = require('gulp-replace'); 			// 文本替换
var uglify = require('gulp-uglify');  			// 压缩js
var uglifycss = require('gulp-uglifycss'); 		// 压缩css
var gutil = require('gulp-util'); 				// 主要用来打印日志
var clean = require('gulp-clean'); 				// 清理目录
var gulpSequence = require('gulp-sequence'); 	// 按顺序执行任务列表
var cmdPack = require('gulp-cmd-pack');  		// seajs打包
var scp = require('gulp-scp2');					// 通过scp命令将本地文件部署到服务器

/**
 * 绑定任务
 * @param  {Object} options 配置参数
 * @param  {String} options.dir 发布的目录地址，如：static/system/detail/3.1.0/
 * @param  {String} options.dist 打包处理文件保存至的目录
 * @param  {Array} options.files 本次需要单独处理的文件列表，如：['detail.js', 'detail.css']，默认值为 []，表示处理所有文件，支持 ['*.js', '*.css']
 * @param  {Array} options.notSeajs 不需要进行seajs构建的文件列表
 * @param  {Array} options.combo 需要进行合并文件处理的文件配置，如：combo: {'addr.js': ['addr.js', 'area.js']}
 * @param  {Boolean} options.notCleanDist 每次打包不需要清理dist目录
 * @param  {Boolean} options.deployByFiles deploy发布是否依据files配置，默认为false，表示将整个dist目录发布
 * @return {undefined}
 */
function bindtask(options)
{
    if(options === undefined || options.dir === undefined) {
    	gutil.log(gutil.colors.red('dir value is undefined!'));
    }
    options = options || {};

    // 不进行seajs构建的文件
    var arrNotSeajs = options.notSeajs || [];

	// 文件发布目录
	var dir = options.dir || '';
	var dist = options.dist || 'dist';

	// 单独处理的文件列表
	var files = options.files || [],
		filesJs = [],
		filesCss = [],
		filesOthers = [],
		distFiles = [];

	if(files.length) {

		for(var i = 0, len = files.length; i < len; i++) {
			if(files[i].indexOf('.js') >= 0) {
				filesJs.push('src/' + files[i]);
			}else if(files[i].indexOf('.css') >= 0) {
				filesCss.push('src/' + files[i]);
			}else{
				filesOthers.push('src/' + files[i]);
			}

			distFiles.push(dist + '/' + files[i]);
		}

	}else {

		filesJs = 'src/*.js';
		filesCss = 'src/*.css';
	}
	

	// 对外的任务名称
	// 使用gulpSequence插件按顺序执行任务列表
	gulp.task('build', gulpSequence('cleanDist', 'copyOthers', 'buildCss', 'buildSeajs', 'combo'));

	// 执行文件的打包处理
	gulp.task('buildSeajs', function(){

	    return gulp.src(filesJs, function(err, files) {

	        // 遍历脚本文件
	        files.map(function(addr){

	            // 截取文件名称
	            var reg = /src\/([^\/]+)\.js$/.exec(addr);
	            if(reg === null) return;
	            var filePath = reg[0];
	            var fileName = reg[1];
	            var fileNameFull = fileName + '.js';

	            // 不进行seajs构建
	            if(arrNotSeajs.indexOf(fileNameFull) !== -1) {

	            	gutil.log('Build ' + addr.replace(/\//g, '\\'));

	            	// 不构建，仅压缩
		            return gulp.src(filePath)
		                .pipe(rename({
		                    suffix: '-debug'
		                }))
		                .pipe(gulp.dest(dist))
		                .pipe(uglify())
		                .pipe(rename(function(path){
		                    path.basename = path.basename.replace('-debug', '');
		                }))
		                .pipe(gulp.dest(dist));

	            }else{

		            // 单独构建
		            return gulp.src(filePath)
		                .pipe(cmdPack({
		                    // base路径
		                    base : './src/',
		                    // 模块id（自动补全脚本文件名，这里给出目录即可）
		                    mainId: dir + fileName,
		                    // 是否合并
		                    isMerge: false,
		                    // 忽略待合并的模块
		                    ignore: []
		                }))
		                .pipe(rename({
		                    suffix: '-debug'
		                }))
		                .pipe(gulp.dest(dist))
		                .pipe(uglify())
		                .pipe(rename(function(path){
		                    path.basename = path.basename.replace('-debug', '');
		                }))
		                .pipe(gulp.dest(dist));
	            }
	        });
	    });
	});

	// 样式处理
	gulp.task('buildCss', ['buildBeforeCss'], function(){
	    return gulp.src(filesCss)
	    		.pipe(replace('../../../../static/global/images/src/', '/static/global/images/1.0.0/'))
	    		.pipe(replace('../../../../static/passport/images/src/', '/static/passport/images/1.0.0/'))	    		
	    		.pipe(replace('../../../../baihuo/static/images/src/', '/baihuo/images/1.0.0/'))	    		
		        .pipe(rename({ suffix: '-debug' }))
		        .pipe(gulp.dest(dist))
		        .pipe(uglifycss())
		        .pipe(rename(function(path){
		            path.basename = path.basename.replace('-debug', '');
		        }))
		        .pipe(gulp.dest(dist));
	});
	gulp.task('buildBeforeCss', function(){
	    gulp.src(filesCss, function(err, files) {
	        files.map(function(addr){
	            gutil.log('Build ' + addr.replace(/\//g, '\\'));
	        });
	    });
	});

	// 其他文件拷贝
	gulp.task('copyOthers', function(){

	    return gulp.src(filesOthers, function(err, files) {

	        // 遍历脚本文件
	        files.map(function(addr){

	        	// 拆分文件目录
	            var match = /src(\/.*\/)[^\/]+\.[a-z]+$/.exec(addr);
	            if(match === null) return;

	            var filePath = match[0]; // 文件路径
	            var fileDir = match[1];  // 文件目录

			    return gulp.src(filePath)
			        .pipe(gulp.dest(dist + fileDir));
	        });
	    });
	});

	// 文件合并
	gulp.task('combo', function(){

		if(options.combo === undefined) return;

		var files, name, i, len,
			filesDebug, nameDebug, temp, hasDir;

		for(name in options.combo) {

			nameDebug = name.replace(/([^\.]+)(\.[a-z]+)$/i, '$1-debug$2');

			files = options.combo[name];
			filesDebug = [];

			for(i = 0, len = files.length; i < len; i++){
				hasDir = files[i].indexOf('../') === 0;
				temp = files[i].replace(/([^\.]+)(\.[a-z]+)$/i, '$1-debug$2');
				files[i] = hasDir ? files[i] : (dist + '/' + files[i]);
				filesDebug[i] = hasDir ? temp : (dist + '/' + temp);
			}

			// // 输出合并信息
			// gutil.log('combo ' + name, files);
			// gutil.log('combo ' + nameDebug, filesDebug);

			// 合并文件的时候，可能dist目录的文件还没生成完成
			setTimeout(function(){

				gulp.src(files)
					.pipe(concat(name))
					.pipe(gulp.dest(dist));

				gulp.src(filesDebug)
					.pipe(concat(nameDebug))
					.pipe(gulp.dest(dist));
			}, 1000);
		}
	});

	// 目录清理
	gulp.task("cleanDist", function(){

		if(options.notCleanDist !== true){
		    return gulp.src('./' + dist)
		        .pipe(clean());	
		}
	});

	gulp.task('deploy', ['move'], function(){
	    return gulp.src(options.deployByFiles ? distFiles : dist + '/**')
	        .pipe(scp({
	            dest: dir
	        }));
	});

	// 将dist目录的文件拷贝至发布svn的对应目录下
	gulp.task('move', function () {

		var nowDate = new Date(),
			year = nowDate.getFullYear(),
			month = nowDate.getMonth() + 1,
			day = nowDate.getDate(),
			timeDir;

		month = month < 10 ? '0' + month : month;
		day = day < 10 ? '0' + day : day;
		timeDir = year + '/' + month + '/' + year + '-' + month + '-' + day;

		// 分销卖场&分销伙伴
		if(options.dir.indexOf('baihuo/') === 0 || options.dir.indexOf('partner/') === 0) {

		    gulp.src(options.deployByFiles ? distFiles : dist + '/**')
		        .pipe(gulp.dest('../../../../Template/yuanchanxidi-webfiles/' + options.dir));
		}
		// 数据中心
		else if(options.dir.indexOf('datacenter/') === 0) {

		    gulp.src(options.deployByFiles ? distFiles : dist + '/**')
		        .pipe(gulp.dest('../../../../Template/datacenter-webfiles/' + options.dir));
		}
		// 喜地卖场
		else if(options.dir.indexOf('static/') === 0) {

		    gulp.src(options.deployByFiles ? distFiles : dist + '/**')
		        .pipe(gulp.dest('../../../../../xidi-beta/delta/pc站/' + timeDir + '_PC卖场_/public/' + options.dir))
		        .pipe(gulp.dest('../../../../../Template/public/' + options.dir));
		}
		// 代表商后台
		else if(options.dir.indexOf('represent/static/') === 0) {

			// 三级目录结构
			if(options.dir.replace(/[^\/]/g, '').length === 6) {
			    gulp.src(options.deployByFiles ? distFiles : dist + '/**')
			        .pipe(gulp.dest('../../../../../xidi-beta/delta/pc站/' + timeDir + '_代表商_/public/' + options.dir))
			        .pipe(gulp.dest('../../../../../Template/public/' + options.dir));
			}
			// 两级目录结构
			else{
			    gulp.src(options.deployByFiles ? distFiles : dist + '/**')
			        .pipe(gulp.dest('../../../../xidi-beta/delta/pc站/' + timeDir + '_代表商_/public/' + options.dir))
			        .pipe(gulp.dest('../../../../Template/public/' + options.dir));
			}
		}
		// component
		else if(options.dir.indexOf('component/') === 0) {

		    gulp.src(options.deployByFiles ? distFiles : dist + '/**')
		        .pipe(gulp.dest('../../../Template/public/' + options.dir))
		        .pipe(gulp.dest('../../../Template/datacenter-webfiles/' + options.dir))
		        .pipe(gulp.dest('../../../Template/yuanchanxidi-webfiles/' + options.dir))
		        .pipe(gulp.dest('../../../xidi-beta/delta/pc站/' + timeDir + '_PC卖场_/public/' + options.dir));
		}
	});
}

module.exports = bindtask;