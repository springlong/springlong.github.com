﻿//公用配置参数
try{
    var test = $$.qqNum;          //测试$$对象是否存在
}catch(e){
    var $$ = {};
}finally{
    $$.siteName = "xian";           //站点名称
    $$.qqNum = "800010082";         //QQ号码
    $$.telNum = "02987401000,4000291000";      //院内电话号码
    $$.telUID = "5417765";          //百度离线宝UID
    $$.addCommentsTime = 1;         //百姓评议单天允许次数
    $$.addInquiresTime = 1;         //费用查询单天允许次数
    $$.addYuyueTime = 1;            //在线挂号单天允许次数
    $$.addAnswerTime = 3;           //在线问答单天允许次数
    $$.zixun = function()           //该函数用于在晚上没有客服人员的情况下，用户点击咨询所执行的替代操作
    {
        window.open("/guahao.html", "_blank");
    }
}

//关于漂浮框的处理代码（自定义商务通邀请框和漂浮框，同时显示其他类型的漂浮框）
(function()
{
    var url = document.URL;
    if(url.indexOf("/register.html") === -1 && url.indexOf("/tel.html") === -1)
    {       
        //如果是在线挂号、电话咨询等收割页面不需要启用漂浮框，所以在前面加了个if判断
        //...

        if(!Extend.isMobile && !Extend.isLowerScreen)
        {
            //除了商务通邀请框之外，其他漂浮框的显示操作应在这里进行
            //因为在手机端访问时或者低分辨率下访问时，不适合显示过多的漂浮框
            //...
        }
    }
})();

//其他处理函数的定义（跟漂浮框相关）
//...

//其他差异化函数的定义（例如JSFrame.js中免费电话使用的是百度离线宝，而该站点则需要使用快商通，那么需要将免费电话的快商通版本的代码书写在这里）
//...