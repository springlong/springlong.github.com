/**
 * @file        针对公司业务进行的脚本封装
 * @version     0.0.1（2014-07-17）
 * @version     0.0.2（2014-09-26）
 * @attention   该脚本文件可先使用YUI压缩，然后再使用JSPacker加密压缩，以进一步压缩文件大小
 */


//========================================================================================================================================
//=============================================基本对象的声明=============================================================================
//=============================================基本对象的声明=============================================================================
//========================================================================================================================================
function getID(id){return (typeof(id) == "string") ? document.getElementById(id) : id;} //根据ID属性获取DOM元素
window.$$ = {};  //用来设置站内的配置参数
window.Extend === undefined && (window.Extend = {}); //所有的站内扩展函数，均放于Extend对象之下

//常用变量的使用
Extend.isMobile = jQuery.browser.isMobile;
Extend.isPad = /ipad|xoom|touchpad|rk30sdk|v811|adr|gt-n8000/i.test(navigator.userAgent);
Extend.isLowerScreen = document.documentElement.clientWidth <= 1024;



//========================================================================================================================================
//=============================================临时处理-临时处理==========================================================================
//=============================================临时处理-临时处理==========================================================================
//========================================================================================================================================
(function($, undefined){

    //=============================================
    //跳转百度URL地址（如果来源地址是百度，则将搜索结果始终保持当前域名下源关键字的搜索）
    //最后调整时间：2014-06-18 15:34
    // function jumpBaiduUrl()
    // {
    //     if(document.referrer.indexOf("www.baidu.com") > 0)
    //     {
    //         var keywords = jQuery.getKeywords("");
    //         var host = /[^\.]+\.(net|com|cn|org)$/.exec(location.host)[0];
            
    //         if(document.referrer.indexOf("&si=") < 0)
    //         {
    //             window.opener.location.href = "http://www.baidu.com/s?ct=2097152&si=" + host + "&wd=" + keywords;
    //         }
    //     }
    // };
    // /\.ent029\.net/.test(location.host) && (jumpBaiduUrl());
    //周一~周五的8:00~18:00不跳，其他时间段一律跳转
    // var now = new Date(),
    //     hour = now.getHours(),
    //     weekDay = now.getDay(),
    //     allow = !(weekDay != 6 && weekDay != 7 && hour >= 8 && hour < 18);
    // if(allow) jumpBaiduUrl();


    //=============================================
    //每次百度用户的访问都将URL、关键词入库，作为恶意点击判断的重要依据
    //最后调整时间：2014-07-17 15:58
    var referrer_url = document.referrer;
    if(referrer_url.indexOf("www.baidu.com") >= 0 || referrer_url.indexOf("m.baidu.com") >= 0)
    {
        jQuery.post("/inc/ajax.ashx?act=checkSpiteHits&host=" + location.hostname + "&keywords=" + escape(jQuery.search_keywords), function(){});
    }


    //=============================================
    //手机访问跳转（地址带有from=mobile、/yynav.html、专题页、平板电脑、本地预览中不进行跳转）
    if(!Extend.isPad && Extend.isMobile && !/localhost|from=mobile|\/yynav\.html|\/zt\//i.test(location.href))
    {
        location.replace("http://video.120zixun.com/jumpMobile.aspx?pathname=" + location.pathname);
    }
})(jQuery, undefined);




//========================================================================================================================================
//=============================================函数兼容-函数兼容==========================================================================
//=============================================函数兼容-函数兼容==========================================================================
//========================================================================================================================================
(function($, undefined){

    $.extend(Extend, {

        tabChange: function(id, eventName, autoChange, delay)
        {
            if(autoChange === true){
                $getID(id).slide({keepTags: true, trigger: eventName === "onclick" ? "click" : "mouseenter" , auto: autoChange, delay: delay});
            }else{
                $getID(id).tab({trigger: eventName === "onclick" ? "click" : "mouseenter" , auto: autoChange, delay: delay });   
            }
        },
        scrollWith: function(id)
        {
            var $ele = $getID(id);
            $ele.children().wrapAll("<div id='" + (id += "Inner") + "' style='width:" + $ele.width() + "px;'></div>").end();
            $getID(id).scrollWith();
        },
        placeHolder: function(id, holderText, holderColor)
        {
            $(function(){
                var $ele = $getID(id);
                $ele.attr("placeholder", holderText);
                !$.support.placeholder && $ele.placeholder();
            });
        },
        AddToFavorite: function()
        {
            $.browser.setHome();
        },
        SetHome: function()
        {
            $.browser.addFavorite();
        },
        setCookie: function(name, value, expires, path, domain, secure)
        {
            $.setCookie(name, value, expires, {path: path, domain: domain, secure: secure});
        },
        getCookie: function(name)
        {
            $.getCookie(name);
        },
        delCookie: function(name, path, domain)
        {
            $.delCookie(name, {path: path, domain: domain});
        },
        getCurrentStyle: function(id, styleName)
        {
            return $getID(id).css(styleName);
        },
        setStyle: function(id, styleName, value)
        {
            $getID(id).css("styleName", value);
        },
        setStyle: function(id, styleName, value)
        {
            $getID(id).css("styleName", value);
        },
        transform: function(id, params, TweenChoose, runAtLast, delay)
        {
            var config = params || {}, duration = (config.duration || 0.4) * 1000;
            $getID(id).animate(params, duration, runAtLast);
        },
        reloadImg: function()
        {
            $("img[init_src]").lazyload({ dataSrc: "init_src" });
        }
    });

    window.webApp === undefined && (window.webApp = {});
    webApp.marquee=function(id, direct, totalTime, delay)
    {
        this.id = id;
        this.ele = $getID(id);
        this.isExist = this.ele.length > 0;  //返回目标容器是否存在；
        this.direct = direct;                //等同于slide中的effect参数
        this.delay = delay;                  //等同于slide中的doMarquee参数
        this.autoChange = true;              //等同于slide中的auto参数
    };
    webApp.marquee.prototype.onInit = function()
    {
        var $ele = this.ele,
            $content = $ele.children().eq(0).addClass("content"),
            effect = this.direct === "left" || this.direct === "right" ? "scrollx" : "scrolly",
            doMarquee = this.delay > 0 ? false : true;

        $ele.append('<div class="btn"><button class="btnPrev" id="' + (this.id + "_Btn1") + '"></button><button class="btnNext" id="' + (this.id + "_Btn2") + '"></button></div>');
        $ele.slide({ contents: $content.children().eq(0).css(effect === "scrollx" ? {"width": "120%"} : {}).children(), effect: effect, auto: this.autoChange, seamless: true, doMarquee: doMarquee });
    };
    webApp.slideshow = function(id, width, height, direction)
    {
        this.id = id;
        this.ele = $getID(id);
        this.width = width;
        this.height = height;
        this.direction = direction;
        this.label = {};
        this.label.visible = true;
        this.labelCurrent = {};
        this.controlBar = {};
        this.autoChange = true;
        this.isExist = this.ele.length > 0;  //返回目标容器是否存在；
    };
    webApp.slideshow.prototype.onInit = function()
    {
        var $ele = this.ele,
            direction = this.direction,
            effect = direction === undefined || direction === "" ? "fade" : (direction === "left" || direction === "right" ? "scrollx" : "scrolly"),
            trigger = this.eventName === "onmouseover" ? "mouseenter" : "click",
            cur = this.currentIndex || 0,
            auto = this.autoChange || true;

        $ele.slide({ trigger: trigger, effect: effect, auto: auto, cur: cur, useDefault: true, showTags: this.label.visible === true });
    };
    window.show_newsbtn = function()
    {
        Extend.showNewsBtn("_#newsInfo", { img:"/images/showszixun.gif", title:"\u70b9\u51fb\u54a8\u8be2\u4e13\u5bb6"}); //ASCII码：点击咨询专家
    }

    //根据ID或者DOM对象构建jQuery
    function $getID(id)
    {
        return $(typeof id === "string" ? "#" + id : id);       
    }
})(jQuery, undefined);




//========================================================================================================================================
//=============================================站内扩展-站内扩展==========================================================================
//=============================================站内扩展-站内扩展==========================================================================
//========================================================================================================================================
jQuery.extend(Extend, {

    /**
     * 文章页表情模块的交互
     * @param  {String} articleID 文章ID
     * @param  {String} [boxID="infoComm"]   容器ID
     * @return {undefined}
     */
    bqOperate: function(articleID, boxID)
    {       
        jQuery(function($)
        {                   
            var $infoCommList = $("#" + (boxID || "infoComm") + " li"),
                baseNums = [{"4":135, "3":29, "2":77, "6":10, "5":558, "1":76}, {"4":40, "3":20, "2":41, "6":59, "5":251, "1":111}, {"4":114, "3":44, "2":32, "6":81, "5":863, "1":102}, {"4":270, "3":54, "2":172, "6":397, "5":1547, "1":162}]
                cookieName = "bqOperate_" + articleID + "_base_index",
                baseIndex = $.getCookie(cookieName);

            //表情系统的基数获取
            if(baseIndex === null){
                baseIndex = $.random(0, baseNums.length - 1);
                $.setCookie(cookieName, baseIndex, 43200); //cookie保存时间30天
            }
            baseNums = location.href.indexOf("?nobqbase") < 0 ? baseNums[baseIndex] : []; //提供查看原始数据的后门
                     
            //读取表情点击数据
            var params = {
                act: "sel",
                aid: articleID,
                bqid: $infoCommList.map(function(){
                    return $(this).data("bqid");
                }).toArray().join(",")
            }
            $.getJSON("http://dingyue.120zixun.com/api/biaoqing.ashx?callback=?", params, function(data){
                if(data && data.state === 1){
                    var hits = data.hits, bqid = params.bqid.split(",");
                    $infoCommList.children(".num").each(function(index){
                        $(this).html(hits[index] + (baseNums[bqid[index]] || 0) + "人");
                    });
                }
            });
            
            //为表情的点击添加数据
            $infoCommList.click(function(){
                var $ele = $(this), bqid = $ele.data("bqid");
                if($ele.data("hited") === "1") return;
                
                //处理+1操作
                var $addDiv = $ele.append("<div class='add'>+1</div>").children(".add");
                $addDiv.css("left", $ele.position().left + 60);
                $addDiv.animate({top: "-20px"}, 500, function(){
                    $addDiv.animate({opacity: "0"}, 1500, function(){
                        $addDiv.remove();
                    });
                });
                
                //远程添加数据
                $.getJSON("http://dingyue.120zixun.com/api/biaoqing.ashx?callback=?",{
                    act: "add",
                    aid: articleID,
                    bqid: bqid
                },function(data){
                    $ele.data("hited", "1");
                    if(data && data.state === 1){
                        $ele.children(".num").html(data.hits + (baseNums[bqid] || 0) + "人");
                    }
                });
                
                //如果是不解，则弹出商务通
                bqid == "1" && (zixun('biaoqing_bujie'));
            });
        });
    },

    /**
     * 通过弹出容器播放视频
     * @param  {Number}  [id=1] 视频ID
     * @param  {Number}  [width=640] 视频宽度
     * @param  {Number}  [height=480] 视频高度
     */
    showVideoBox: function(id, width, height)
    {
        //参数校验
        id = id || 1;
        width = width || 640;
        height = height || 480;
        
        //变量声明
        var $videoBox = $("#videoBox"),
            $videoPlay = $("#videoBoxPlay"),
            src = "http://video.120zixun.com/videoplay.aspx?id=" + id + "&width=" + width + "&height=" + height + "&autoPlay=1&allowFullScreen=1&hideControler=1&" + (arguments[3] || ""),
            html;
            
        //显示容器
        if($videoBox.length > 0 && $videoPlay.length > 0)
        {
            $videoPlay.attr("src", src);
            doShow();
        }
        else
        {
            html =  '<div id="videoBoxAlpha" style="position:fixed;left:0;top:0;z-index:2147483647;width:100%;height:100%;background:#000;opacity:0.8;filter:alpha(opacity=80);_position:absolute;_top:expression(documentElement.scrollTop);"></div>';
            html += '<div id="videoBoxContent" style="position:fixed;left:50%;z-index:2147483647;overflow:hidden;width:' + width + 'px;height:' + height + 'px;margin:0 0 0 -' + Math.round(width/2 + 10) + 'px;padding:20px 10px;background:#000;_position:absolute;_margin-top:0;_top:expression(eval(document.documentElement.scrollTop+parseInt(document.documentElement.clientHeight*0.9-this.offsetHeight)/2));">';
            html += '   <iframe id="videoBoxPlay" src="' + src + '" frameborder="0" width="' + width + '" scrolling="no" height="' + height + '"></iframe>';
            html += '   <span id="videoBoxClose" style="position:absolute;right:5px;top:0;font-size:12px;line-height:20px;color:#999;cursor:pointer;">\u5173\u95ed</span>';
            html += '</div>';        
            $(document.body).append('<div id="videoBox">' + html + '</div>');

            $("#videoBoxClose").click(function(){
                $("#videoBox").hide();
                $("#videoBoxPlay").attr("src", "about:blank");
            });

            $.browser.isIE6 && (document.body.style.height = "100%"); //针对IE6设置body的高度为100%，修复蒙版图层高度不100%的问题
            doShow();
        }

        //执行显示处理
        function doShow()
        {
            $("#videoBox").show();
            !$.browser.isIE6 && $("#videoBoxContent").css("top", -height*1.2 + "px").animate({top: ($(window).height() - height) / 2 * 0.75}, 1200, "easeInOutBack");
        }
    },

    /**
     * 针对活动专题到期时的提示内容设置
     * @param  {String}  timeStr 过期时间字符串，格式如："2014-03-08 0:00"
     * @param  {String}  [tips]  提示文本，默认值为：本活动已过期，如有疑问请<span onclick=zixun('expires') style=text-decoration:underline;color:orange;cursor:pointer;>咨询</span>在线专家！
     */
    expires: function(timeStr, tips)
    {
        //变量默认值
        tips = tips || "\u672c\u6d3b\u52a8\u5df2\u8fc7\u671f\uff0c\u5982\u6709\u7591\u95ee\u8bf7<span onclick=zixun('expires') style=text-decoration:underline;color:orange;cursor:pointer;>\u54a8\u8be2</span>\u5728\u7ebf\u4e13\u5bb6\uff01";

        //创建容器
        var $tipsBox, $body = $(document.body);
        $body.append("<div id='expiresTipsBox' style='position:fixed;left:0;top:0;z-index:2147483647;display:none;width:100%;height:100%;_position:absolute;_top:expression(documentElement.scrollTop);'><div style='position:absolute;left:0;top:0;width:100%;height:100%;background-color:#000;opacity:0.6;filter:alpha(opacity=60);'></div><div style='position:absolute;left:50%;top:20px;width:400px;height:50px;margin-left:-200px;background:green;color:#fff;font-size:18px;line-height:50px;text-align:center;'>" + tips + "</div></div>");
        $tipsBox = $("#expiresTipsBox");

        //针对IE6设置body的高度为100%，修复蒙版图层高度不100%的问题
        if(!window.XMLHttpRequest){
            document.body.style.height = "100%";
        }
        
        //从服务器端获取标准时间与过期时间进行判断
        jQuery.post("/inc/ajax.ashx?act=timeNow", function()
        {
            var expires = new Date(timeStr.replace(/-/g, "/")).valueOf();   //过期时间，"2014-03-08"格式的时间字符串在IE中不支持
            var timeNow = new Date(arguments[0]).valueOf();                 //系统当前时间
            if(isNaN(timeNow)){ timeNow = Date.now(); }                     //如果服务器端没有返回正确的日期时间值，则使用本机时间进行纠正
            
            if(expires < timeNow)
            {
                $tipsBox.show();

                //点击隐藏
                $tipsBox.children().eq(0).click(function(e){
                    $tipsBox.hide();
                });

                //按“ESC”键取消
                $body.on("keyup", function(e){
                    e.keyCode == 27 && $tipsBox.hide();
                });
            }
        });
    },

    /**
     * 为文本输入框添加占位文本的打字机效果
     * @param  {String} id   文本框的ID属性
     * @return {undefined}
     */
    typing: function(id)
    {
        var $obj = $("#" + id),
            oldColor = $obj.css("color"),  //默认颜色
            typeColor = "#c1c1c1",         //打字效果的颜色
            duration = 200,     //每个打字效果的所需时间
            delay = 2000,       //每一轮打字效果的时间间隔
            stopID = 0,         //用于计时器ID
            typing = 1,         //标识该文本处于打字状态，0表示停止状态，1表示打字效果状态
            idx = 0,            //保存当前显示文本内容结束于打字文本的索引位置
            len, text;
        
        text = $obj.attr("placeholder") || "";
        len = text.length;
        $obj.data("typeText", text);  //将打字文本内容提供给外部访问

        if(len > 1)
        {
            $obj.focus(function(e){
                clearInterval(stopID);
                typing = 0;
                if(text.indexOf(this.value) === 0){
                    if($obj.attr("placeholder") && !$.support.placeholder){
                        this.value = $obj.attr("placeholder");
                        $.setTextPosition(this, 0);
                    }else{
                        this.value = "";
                        $obj.css("color", oldColor);   
                    }
                }
            });
            $obj.blur(function(e){
                if(text.indexOf(this.value) === 0){
                    typing = 1;
                    idx = 0;
                    $obj.css("color", typeColor);
                    doTyping();
                }
            });
            $obj.css("color", typeColor);
            doTyping();
        }

        function doTyping()
        {
            clearInterval(stopID);
            stopID = setInterval(function()
            {
                $obj.val(text.substring(0, ++idx));
                if(idx === len){
                    idx = 0;
                    clearInterval(stopID);
                    setTimeout(function(){
                        if(typing === 1){
                            $obj.val(text.substring(0, idx));
                            doTyping();
                        }
                    }, delay);
                }
            }, duration);
        }
    },

    /**
     * 执行站内的搜索跳转（跳转URL类似于："/search/关键字文本.html"）。
     * 程序标准参数结构为：function(text, button, params)。
     * 考虑到向后兼容，所以使用参数结构为：function(text, button, tips, isKey, prefix, suffix, newPage) 
     * @param  {String}  text               搜索文本框的ID属性
     * @param  {String}  button             搜索按钮的ID属性
     * @param  {Object}  params             扩展参数配置
     * @param  {String}  params.tips        文本框显示的占位文本，当文本框没有设置placeholder属性时有效，该属性仅用于向后兼容，不建议使用。默认为："请输入您所需查询的内容"
     * @param  {Boolean} params.isKey       占位文本是否作为关键词进行搜索，默认为：false
     * @param  {String}  params.prefix      搜索URL的前缀字符串，默认为："/search/"
     * @param  {String}  params.suffix      搜索URL的后缀字符串，默认为：".html"
     * @param  {Boolean}  params.newPage    搜索页面是否在新窗口打开，默认为：true  
     * @return {undefined}
     */
    //search: function(text, button, params)
    search: function(text, button, tips, isKey, prefix, suffix, newPage) 
    {
        //对参数列表进行兼容处理
        var params = arguments[2], config, err, $text, $button;
        if(!$.isPlainObject(params)){
            params = {tips: tips, isKey: isKey, prefix: prefix, suffix: suffix, newPage: newPage};
        }
        config = $.extend({
            tips: "",
            isKey: false,
            prefix: "/search/",
            suffix: ".html",
            newPage: true
        }, params);
        err = "\u8bf7\u8f93\u5165\u60a8\u6240\u9700\u67e5\u8be2\u7684\u5185\u5bb9..."; //ASCII码字符：请输入您所需查询的内容
        tips = config.tips || err;
        isKey = config.isKey;
        prefix = config.prefix;
        suffix = config.suffix;
        newPage = config.newPage;
        $text = $("#" + (text || "txtKey"));
        $button = $("#" + (button || "btnSearch"));

        $text.attr("placeholder") === undefined && $text.attr("placeholder", tips).placeholder(); //设置占位文本
        $text.keypress(function(e){
            e.keyCode === 13 && doJump(); //按回车键跳转
        });
        $button.click(doJump); //点击按钮将进行跳转

        //执行跳转
        function doJump()
        {
            var value = $text.val().replace(/^\s*|\s*$/g, ""); //去掉关键字输入框中的前尾空格！
            var isTyping = value !== "" && ($text.data("typeText") + "").indexOf(value) === 0;

            $text.val(value); 
            if(value === "" && $.support.placeholder || isTyping && isKey){ value = $text.attr("placeholder") }

            if(((value === tips || isTyping) && !isKey) || value === ""){
                alert(err);
                $text[0].focus();
            }else{
                if(newPage){
                    window.open(prefix + encodeURI(value) + suffix, "_blank");
                }else{
                    location.href = prefix + encodeURI(value) + suffix;
                }
            }
        }
    },

    /**
     * 仿QQ抖动，实现目标定位元素的窗口抖动效果。
     * 由于我数学不好，所以使用了很死的方法来实现该效果。
     * @param  {String} id       抖动窗口的ID属性值
     * @param  {Number} speed    抖动的速度，默认为30s
     * @param  {Number} duration 单次抖动持续的时间，默认为：1200s
     * @param  {Number} delay    单次抖动后延时多长时间进入到下一轮抖动，如果不传递该参数则仅实现单次抖动
     * @return {undefined}
     */
    shake: function(id, speed, duration, delay)
    {
        var $ele = $("#" + id),
            data = $ele.data("doShake");

        if(typeof data === "function"){
            return data();  //二次重复调用不再执行后续代码，均采用上一次的参数设置
        }

        var initLeft = parseInt($ele.css("left")) || 0,
            initTop = parseInt($ele.css("top")) || 0,
            step = 0,
            shakeID;

        speed = speed || 30;
        duration = duration || 1200; 

        var doStart = function(){
            if($ele.is(":hidden")) return;
            clearInterval(shakeID);
            shakeID = setInterval(function(){
                switch(++step){
                    case 1: $ele.css("left", initLeft - 2); break;
                    case 2: $ele.css("top", initTop - 2); break;
                    case 3: $ele.css("left", initLeft + 2); break;
                    case 4: $ele.css("top", initTop + 2); step = 0;
                }
            }, speed);
            doStop();
        };

        var doStop = function(){
            setTimeout(function(){
                clearInterval(shakeID);
                $ele.css({left: initLeft, top: initTop});
                delay && setTimeout(function(){
                    doStart();
                }, delay);
            }, duration);
        };

        doStart();
        $ele.data("doShake", doStart);
    },

    /**
      * 用于实现页面文字选中后弹出一个咨询按钮。实现方案：
      * 1. 提供一个id参数，用于设置文本选择效果所针对的容器范围；
      * 2. 当点击鼠标键且松开时，如果在指定的id容器范围内拥有选中文本，则在鼠标位置显示链接按钮；
      * 3. 当链接按钮处于显示状态，再次点击鼠标且松开，如果在指定的ID容器范围内没有选中文本，则隐藏链接按钮。
      * @param  {String} id     容器的ID属性值，该函数效果仅针对该容器内有效
      * @param  {Object} params 参数列表
      * @param  {String} params.url 点击按钮后将会触发的链接地址，当地址中包含"zixun("时，则作为咨询按钮来使用;
      * @param  {String} params.img 按钮图片的url路径;
      * @param  {String} params.title 按钮图片的提示文本;
      * @return {undefined}
      */
    showNewsBtn: function(id, params)
    {
        var config = $.extend({
                url: "zixun('newsBtn')",
                img: "/images/public/showszixun.gif",
                title: ""
            }, params),
            htmlStr, $btn, $doc = $(document.body), oContainer = document.getElementById(id);

        //添加元素
        if(config.url.indexOf("zixun(") === 0){
            htmlStr = "<a href=\"javascript:void(0);\" target=\"_self\" onclick=\"" + config.url + "\"><img style=\"display:block;vertical-align:baseline;\" src=\"" + config.img + "\" title=\"" + config.title + "\" /></a>";
        }else{
            htmlStr = "<a href=\"" + config.url + "\" target=\"_blank\"><img style=\"display:block;vertical-align:baseline;\" src=\"" + config.img + "\" title=\"" + config.title + "\" /></a>";   
        }
        $doc.append('<div id="showNewsBtn" style="position:absolute;left:-9999px;top:0;display:none;">' + htmlStr + '</div>');
        $btn = $("#showNewsBtn");

        //事件触发
        $doc.mousedown(function(e){
            $btn.data("lastY", e.pageY);  //用于记录鼠标按下时的位置
        });
        $doc.mouseup(function(e){
            var str = (document.selection ? document.selection.createRange().text : document.getSelection()) + "";        //获取当前浏览器鼠标选中的文本内容
            if(str !== "" && $btn.data("selectText") !== str && oContainer.contains(e.target)){
                var nowY = e.pageY;  //用于记录鼠标松开时的位置
                var boolDown = nowY > $btn.data("lastY");  //鼠标是否为向下运动
                $btn.css({left: e.pageX, top: nowY - (boolDown ? -20 : $btn.outerHeight() + 20)}).data("selectText", str).show();
            }else if(!$btn[0].contains(e.target)){
                $btn.data("selectText", "").hide();
            }
        });
    },

    /**
     * 在指定iframe中打开url链接
     * @param  {String} id 框架的id属性
     * @param  {String} url 需要打开的url链接
     * @return {String} 返回name参数值
     */
    openInIframe: function(id, url)
    {
        url = url || id || "about:blank";  //如果该函数没有传递url参数，则默认为第一个参数的值；如果没有传递任何参数则默认为“about:blank”
        id = arguments.length < 2 ? "openUrl" : id; //如果参数个数小于2，则框架的id默认为“openURL”

        var $iframe = $("#"+id);
        if($iframe.length === 0){
            $(document.body).append('<iframe id="' + id + '" name="' + id + '" src="' + url + '" style="position:absolute;left:-9999px;overflow:hidden;width:0px;height:0px;"></iframe>');
        }else{
            $iframe.attr("src", url);
        }
    }
});




//========================================================================================================================================
//=============================================数据提交-数据提交==========================================================================
//=============================================数据提交-数据提交==========================================================================
//========================================================================================================================================
(function($, undefined){

    //将数据提交函数统一放于Extend对象中进行管理
    $.extend(Extend, {

        //向服务器添加“预约”类数据，包括正常的“预约挂号”模块、以及特殊的在线报名、在线申请等模块
        addYuyue: function(){
            addYuyue.apply(this, arguments);
        },

        //向服务器添加“咨询”类数据，即除预约挂号、在线问答之外的其他数据，如在线留言、费用查询、百姓评议、投诉建议、疾病自测等模块
        addData: function(){
            addData.apply(this, arguments);
        },

        //向服务器添加“问答”类数据，通常仅用户在线问答页面
        addAnswer: function(){
            addAnswer.apply(this, arguments);
        },

        /**
         * 拨打电话
         * @param  {String} phone 该值既可以是一个具体的电话号码，也可以是用于输入电话号码的文本框ID。
         * @param  {String} label 标签，用来标识是从哪个地方点击触发的，默认为电话号码的文本框ID。，如果参数phone表示一个电话号码则被设置为“doTel”
         * @return {undefined}
         */
        doTel: function(phone, label)
        {
            var $button = $(this),  //拨打按钮
                $frm = $button.closest("form"), //按钮所在表单
                label = label || (typeof phone === "string" ? phone : "doTel"), //标注事件触发的标签
                isNum = !isNaN(phone),  //phone参数是否作为一个电话号码使用，而非文本框的ID
                $phone = isNum ? phone : $("#" + phone), //电话输入文本框
                tel = "",   //电话号码
                useKst = false, //是否使用快商通
                errorTips = "\u670d\u52a1\u5668\u6b63\u5fd9\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\uff01";  //ASCII码字符：服务器正忙，请稍后再试！
            
            //禁用cookie视为非法请求
            if(!navigator.cookieEnabled) return;

            //电话号码的有效性判断
            tel = isNum ? $phone : $phone.val();
            if(("," + $$.telNum + ",").indexOf("," + tel + ",") !== -1){
                alert("\u4e0d\u53ef\u620f\u5f04\u672c\u9662\u7535\u8bdd\u54e6\uff0c\u4eb2\uff01");   //ASCII码字符：不可戏弄本院电话哦，亲！
                return;
            }
            if(!/^[1]{1}[3,4,5,8]{1}\d{9}$/.test(tel) && !/^[0]{1}\d{10,11}$/.test(tel)){
                alert("\u60a8\u7684\u7535\u8bdd\u53f7\u7801\u8f93\u5165\u6709\u8bef\uff01");  //ASCII码字符为：您的电话号码输入有误！
                if(!isNum){
                    $phone.focus().select();   
                }
                return;
            }
            
            //在请求前将按钮禁用，避免多次重复点击请求
            $button.prop("disabled", true);
            if(useKst)
            {
                //进行快商通电话拨打
                jQuery.post("/inc/ajax.ashx?act=kuaishangtong&txtclassid=&txttype=" + escape("\u514d\u8d39\u7535\u8bdd"/*ASCII字符：免费电话*/) + "&txtphone=" + escape(tel) + "&txtdetails=&txtpage=" + escape(location.href + "?label=" + label), function()
                {
                    var result = arguments[0];
                    alert(result);

                    $button.prop("disabled", false); //恢复按钮激活状态
                    if($frm.length > 0) $frm[0].reset(); //重置表单
                    if(!isNum && $frm.length <= 0) phone.value = ""; //在没有表单的情况下重置文本框
                    
                    //向数据库插入记录（ASCII码字符：电话正在连接中）
                    if(result.indexOf("\u7535\u8bdd\u6b63\u5728\u8fde\u63a5\u4e2d") >= 0){
                        jQuery.post("/inc/ajax.ashx?act=doTel&txtclassid=&txttype=" + escape("\u514d\u8d39\u7535\u8bdd"/*ASCII字符：免费电话*/) + "&txtphone=" + escape(tel) + "&txtdetails=&txtpage=" + escape(location.href + "?label=" + label) + "&keywords=" + escape(jQuery.search_keywords) + "&source=" + escape(jQuery.search_source) + "&page_referrer=" + escape(document.referrer), function(){});            
                    }
                });
            }
            else
            {
                //调用百度离线宝回呼接口获取token，返回结果如：{"status":0,"data":{"cnum":"","tk":"0C235DB26A057402291B2C9EE2866CB31216FB00A3E254A0927E7E22626154925B01B5C3BC4EB744C074275B3AE05C2F8DE2B95340BA1A7C","ext":""}}
                jQuery.getJSON("http://lxbjs.baidu.com/cb/user/check?f=4&uid=" + $$.telUID + "&r=" + escape(location.href) + "&t=" + new Date().valueOf() + "&callback=?", function(token)
                {
                    if(token.status === 0){
                        token = token.data.tk;
                        //调用百度离线宝回呼接口进行电话呼叫，返回结果如：{"status":0,"msg":"稍后您将接到我们的电话，该通话对您完全免费，请放心接听！"}
                        jQuery.getJSON("http://lxbjs.baidu.com/cb/call?vtel=" + tel + "&uid=" + $$.telUID + "&tk=" + token + "&t=" + new Date().valueOf() + "&callback=?", function(result)
                        {
                            alert(result.msg || errorTips);

                            $button.prop("disabled", false); //恢复按钮激活状态
                            if($frm.length > 0) $frm[0].reset(); //重置表单
                            if(!isNum && $frm.length <= 0) phone.value = ""; //在没有表单的情况下重置文本框

                            //除“135”和“152”之外的所有状态，一律将请求记录加入到项目管理系统（135——供应商接口校验，访客号码不正确；152——vtel不合法，即电话号码不合法）
                            if(",135,152,".indexOf("," + result.status + ",") < 0){                                 
                                jQuery.post("/inc/ajax.ashx?act=doTel&txtclassid=&txttype=" + escape("\u514d\u8d39\u7535\u8bdd"/*ASCII字符：免费电话*/) + "&txtphone=" + escape(tel) + "&txtdetails=" + escape("\u3010\u63d0\u793a\u6587\u672c\u3011" + result.msg) + "&txtpage=" + escape(location.href + (location.search == "" ? "?label=" : "&label=") + label) + "&keywords=" + escape(jQuery.search_keywords) + "&source=" + escape(jQuery.search_source) + "&page_referrer=" + escape(document.referrer), function(){});
                            }
                        });
                    }else{
                        alert(errorTips);
                        $button.prop("disabled", false); //恢复按钮激活状态
                    }
                });
            }
        }

    });

    //向服务器添加“预约”类数据，包括正常的“预约挂号”模块、以及特殊的在线报名、在线申请等模块
    function addYuyue(button, params, callback)
    {
        if(typeof params === "function"){
            //如果没有需要自定义的参数配置，则允许将第二个参数作为回调函数使用
            callback = params;
            params = {};
        }
        var config = $.extend({
            act: "register",
            classid: "0",
            desc: "\u9884\u7ea6\u6302\u53f7", //ASCII码字符：预约挂号
            tips: "\u60a8\u7684\u9884\u7ea6\u5df2\u7ecf\u63d0\u4ea4\u6210\u529f\uff0c\u8bf7\u4fdd\u6301\u7535\u8bdd\u7545\u901a\uff0c\u65b9\u4fbf\u6211\u9662\u56de\u8bbf\u786e\u8ba4\u3002" //ASCII码字符：您的预约已经提交成功，请保持电话畅通，方便我院回访确认。
        }, params);
        if(config.desc !== "\u9884\u7ea6\u6302\u53f7") config.act = "addYuyue";
        submitData(button, config, callback);
    }

    //向服务器添加“咨询”类数据，即除预约挂号、在线问答之外的其他数据，如在线留言、费用查询、百姓评议、投诉建议、疾病自测等模块
    function addData(button, params, callback)
    {
        if(typeof params === "function"){
            //如果没有需要自定义的参数配置，则允许将第二个参数作为回调函数使用
            callback = params;
            params = {};
        }
        var config = $.extend({
            act: "addData",
            classid: "1",
            desc: "\u5185\u5bb9\u54a8\u8be2", //ASCII码字符：内容咨询
            tips: "\u60a8\u7684\u5185\u5bb9\u5df2\u7ecf\u63d0\u4ea4\u6210\u529f\uff0c\u8bf7\u4fdd\u6301\u7535\u8bdd\u7545\u901a\uff0c\u65b9\u4fbf\u6211\u9662\u4e0e\u60a8\u8054\u7cfb\u3002" //ASCII码字符：您的内容已经提交成功，请保持电话畅通，方便我院与您联系。
        }, params);
        submitData(button, config, callback);
    }

    //向服务器添加“问答”类数据，通常仅用户在线问答页面
    function addAnswer(button, params, callback)
    {
        if(typeof params === "function"){
            //如果没有需要自定义的参数配置，则允许将第二个参数作为回调函数使用
            callback = params;
            params = {};
        }
        var config = $.extend({
            act: "addAnswer",
            classid: "2",
            desc: "\u5728\u7ebf\u95ee\u7b54", //ASCII码字符：在线问答
            tips: "\u60a8\u7684\u95ee\u9898\u5df2\u7ecf\u63d0\u4ea4\u6210\u529f\uff01\u6211\u4eec\u7684\u4e13\u5bb6\u5c06\u4f1a\u4e8e24\u5c0f\u65f6\u4e4b\u5185\u5bf9\u60a8\u7684\u95ee\u9898\u8fdb\u884c\u56de\u590d\uff0c\u8bf7\u8010\u5fc3\u7b49\u5f85\u3002" //ASCII码字符：您的问题已经提交成功！我们的专家将会于24小时之内对您的问题进行回复，请耐心等待。
        }, params);
        submitData(button, config, callback);
    }

    /**
     * 预约挂号、在线提问、费用查询、百姓评议等数据提交的统一处理接口
     * @param {DOMElement}   button      表单的提交按钮
     * @param {Object}   params          扩展参数配置
     * @param {String}   params.act      操作类型的标识符（register：向服务器添加预约挂号数据，服务器会自动生成预约号；addYuyue：向服务器添加“预约”类数据，主要用于在线报名、在线申请等特殊的预约模块，服务器不会生成预约号；addData：向服务器添加“咨询”类数据，即除预约挂号、在线问答之外的其他数据，如在线留言、费用查询、百姓评议、投诉建议、疾病自测等模块；addAnswer：向服务器添加“问答”类数据，通常仅用于在线问答页面；）
     * @param {String}   params.classid  数据类型（"0"：预约挂号；"1"：内容咨询；"2"：在线问答；），默认为"0"。
     * @param {String}   params.desc     分类描述，如："预约挂号"、"在线报名"、"在线申请"、"在线留言"等，默认为"预约挂号"。
     * @param {Boolean}  params.yyh      是否需要在服务器返回的内容中包含预约信息，如果是则服务器返回的内容将以“xxx预约号xxx提交时间xxx”的形式为前缀，例如："xxxM240958xxx2014-09-24xxx"。
     * @param {String}   params.tips     提交成功后的提示文本，默认为"您的数据已经提交成功，请保持电话畅通，方便我院回访确认。"。
     * @param {String}   params.addCont  需要向服务器追加的额外内容，默认为""。
     * @param {Function} callback 回调函数，数据提交成功时触发。回调函数传递两个参数，第一个参数是从表单各字段收集整理的数据对象，例如：{name: {desc: "姓名", value: "阳团"}, age: {desc: "年龄", value: "22"}, append: {qq: {desc: "QQ号码", value: "569320261"}, addr: {desc: "地址", value: "湖南"}}}；第二个参数是从服务器返回的内容参数
     */
    function submitData(button, params, callback)
    {
        //参数的向后兼容处理
        var config, $frm, $eles, $captcha, captchaValue, contact, radios = {}, data = {}, canGoOn, err = "", append = "", details = "", original = ",name,sex,age,phone,content,discate,date,";
        config = $.extend({
            act: "yuyue",
            classid: "0",
            yyh: false,
            desc: "\u9884\u7ea6\u6302\u53f7", //ASCII码字符：预约挂号
            tips: "\u60a8\u7684\u6570\u636e\u5df2\u7ecf\u63d0\u4ea4\u6210\u529f\uff0c\u8bf7\u4fdd\u6301\u7535\u8bdd\u7545\u901a\uff0c\u65b9\u4fbf\u6211\u9662\u56de\u8bbf\u786e\u8ba4\u3002", //ASCII码字符：您的数据已经提交成功，请保持电话畅通，方便我院回访确认。
            addCont: ""
        }, params);

        // 禁用cookie视为非法请求！
        if(!navigator.cookieEnabled) return;

        //表单元素
        $button = $(button);
        $frm = $button.closest("form");
        $eles = $frm.find("input[id],select[id],textarea[id]").filter(function(){ //仅针对文本框、文本域、下拉框、单选按钮且带有ID属性的可视字段进行处理
            return $(this).is(":visible") && !$(this).is(":checkbox");
        });

        //控制提交的次数
        var submitTimes = $.getCookie(config.act);
        if(submitTimes === null){
            submitTimes = 0;
            $.setCookie(config.act, submitTimes, 60);
        }else if(parseInt(submitTimes) >= 2 && location.href.indexOf("localhost") === -1){
            alert("\u64cd\u4f5c\u5931\u8d25\uff01\u8bf7\u52ff\u91cd\u590d\u63d0\u4ea4\uff0c\u5982\u6709\u7591\u95ee\u8bf7\u54a8\u8be2\u5728\u7ebf\u4e13\u5bb6\uff01");    //ASCII码字符：操作失败！请勿重复提交，如有疑问请咨询在线专家！
            $frm.length > 0 && $frm[0].reset();
            return false;
        }

        //数据处理
        $eles.each(function(i, ele){
            var $ele = $(ele),  //所需填入内容的表单元素，后续注释文本将描述为“表单字段”
                $desc = $ele.prev(),  //对表单字段的描述内容的容器
                name = $ele.attr("id").replace(/^[a-z]*/, "").toLowerCase(),  //表单字段的名称，例如id属性为“yyName”，则该字段的名称为“name”，表示访客的姓名
                value = $ele.val() || "",  //表单字段所填入的内容（值可能是null）
                desc = $ele.data("desc") || $desc.text(), //对表单字段的描述文本
                required = $ele.hasClass("required"), //是否要求必填
                radiosName; //单选按钮的名称

            //验证码需要单独处理
            if($ele.attr("id").indexOf("Captcha") >= 0){
                $captcha = $ele;
                return;
            }

            //精确描述文本的内容
            $desc.children().each(function(i, ele){
                desc = desc.replace($(ele).text(), "");
            });
            desc = desc.replace(/：|\s/g, "");

            //针对单选按钮组做特别处理
            if($ele.is(":radio")){
                radiosName = $ele.attr("name");
                if(radios[radiosName] !== undefined) return;

                name = radiosName;  //更新单选按钮的字段名称
                value = getRadioName($frm, radiosName); //获取单选按钮组的值
                radios[radiosName] = 1;  //标注当前单选按钮已入库
            }

            //删除文本框中首尾两端的空白字符
            $ele.val(value = value.replace(/^\s*|\s*$/g, "")); 

            //如果值是占位文本，则作为空处理
            if($ele.attr("placeholder") === value){
                value = "";
            }

            //数据有效性判断
            if(required && value === "") err = "\u201c" + desc + "\u201d\u4e0d\u80fd\u4e3a\u7a7a\uff01"; //必填字段，要求不能为空（ASCII码字符：“姓名”不能为空！）
            if(!checkForm(name, value)) err = "\u201c" + desc + "\u201d\u8f93\u5165\u6709\u8bef\uff01"; //判断字段数据的有效性（ASCII码字符：“姓名”输入有误！）
            if(err !== ""){
                alert(err);
                $ele.focus().select();
                canGoOn = false;
                return false;  //返回false将结束遍历
            }

            //将表单数据保存为一个对象，可供回调函数使用
            if(original.indexOf("," + name + ",") < 0){
                //将不为空的附加信息进行组合
                value !== "" && (append += "[br]\u3010" + desc + "\u3011" + value);

                //将附加信息保存至data对象
                if(data.append === undefined) data.append = {};
                data.append[name] = {}
                data.append[name].desc = desc;
                data.append[name].value = value;
            }else{
                //将标准的字段信息保存至data对象中
                data[name] = {};
                data[name].desc = desc;
                data[name].value = value;   
            }

            //标注联系方式是否为空
            if(name === "phone" || name === "mail" || name === "qq"){
                contact = contact === undefined ? value : contact + value;
            }
        });

        if(canGoOn !== false)
        {
            //必须要求有一项联系方式被填写
            if(contact !== undefined && contact === ""){
                alert("\u8bf7\u81f3\u5c11\u8f93\u5165\u4e00\u9879\u8054\u7cfb\u65b9\u5f0f\uff01");  //ASCII码字符：请至少输入一项联系方式！
                return;
            }

            //将附加信息与content字段的内容组合成新的details变量
            if(data.content && data.content.value !== ""){
                details = "\u3010" + data.content.desc + "\u3011" + data.content.value;
            }
            if(append !== ""){
                details += details === "" ? append.substring(4) : append;
            }
            details += config.addCont;

            //请求处理函数
            var doAjax = function()
            {
                var strYYH = config.yyh ? "&yyh=1" : "";
                var params = "act=" + config.act + "&txtclassid=" + config.classid + "&txttype=" + escape(config.desc) + strYYH + "&txtrealname=" + escape(data.name && data.name.value || "") + "&txtsex=" + escape(data.sex && data.sex.value || "") + "&txtage=" + escape(data.age && data.age.value || "") + "&txtphone=" + escape(data.phone && data.phone.value || "") + "&txtdetails=" + escape(details) + "&txtdiscate=" + escape(data.discate && data.discate.value || "") + "&txtordertime=" + escape(data.date && data.date.value || "") + "&tips=" + escape($.encodeHTML(config.tips)) + "&txtpage=" + escape($.addUrlQuery(location.href, "label", config.prefix)) + "&keywords=" + escape($.search_keywords) + "&source=" + escape($.search_source) + "&page_referrer=" + escape(document.referrer);

                button.disabled = true; //在请求前将按钮禁用，避免多次重复点击请求
                $.post("/inc/ajax.ashx?" + params, function()
                {
                    var returnCont = arguments[0];
                    var doCallback = typeof callback === "function" ? callback : undefined;
                    var isErr = returnCont.indexOf("\u670d\u52a1\u5668\u6b63\u5fd9") >= 0 && returnCont.indexOf("\u64cd\u4f5c\u672a\u80fd\u6210\u529f") >= 0; //ASCII字符-1："服务器正忙"；ASCII字符-2："操作未能成功"
                    
                    button.disabled = false; //恢复按钮激活状态
                    if(isErr){
                        alert(returnCont);
                    }else if(doCallback === undefined){
                        //提交成功时如果有回调函数，则不提示返回文本
                        alert(config.tips);
                    }
                        
                    if(!isErr){
                        $.setCookie(config.act, parseInt(submitTimes) + 1, 60);
                        doCallback !== undefined && doCallback(data, returnCont);
                        $frm.length > 0 && $frm[0].reset();
                    }
                });
            }

            //判断是否存在验证码
            if($captcha !== undefined){
                captchaValue = $captcha.val().replace(/^\s*|\s*$/g, "");
                if(captchaValue === ""){
                    alert("\u8bf7\u8f93\u5165\u9a8c\u8bc1\u7801\uff01");  //ASCII码字符：请输入验证码！
                    $captcha.focus().select();
                    return;
                }
                
                $.get("/inc/ajax_code.aspx?act=CheckCode&txtCaptcha=" + captchaValue, function(){
                    if(arguments[0] === "ok"){
                        doAjax();
                    }else{
                        alert(arguments[0]);
                        $captcha.focus().select();
                    }
                });
            }else{
                doAjax();    
            }            
        }
    }

    /**
     * 检测指定表单字段的内容是否为有效值
     * @param  {String} name  字段名称
     * @param  {String} value 字段的内容
     * @return {Boolean}      有效则返回true，否则返回false
     */
    function checkForm(name, value)
    {
        var result, yyDate, time, now;
        if(value === "") return true;  //值为空的情况下视为有效；在实际操作中，往往需要额外对表单字段进行是否为空的检查和判断
        switch(name)
        {
            //年龄
            case "age":
                result = value >= 1 && value <= 100;
                break;

            //QQ号码
            case "qq":
                result = /[1-9][0-9]{4,}/.test(value);
                break;

            //电话号码
            case "phone":
                result = /^[1]{1}[3,4,5,8]{1}\d{9}$/.test(value) || /^[0]{1}\d{10,11}$/.test(value);
                break;

            //日期（不得低于当前日期）
            case "date":
                yyDate  = Date.parse(value.replace(/-/g, "/")),
                time = new Date(),
                now = new Date(time.getFullYear(), time.getMonth(), time.getDate());
                result = !isNaN(yyDate) && yyDate >= now;
                break;

            //身份证号码
            case "idcard":
                result = /\d{17}[\d|x]|\d{15}/i.test(value);
                break;

            //电子邮箱
            case "mail":
                result = /[\w!#$%&'*+\/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/i.test(value);
                break;

            //普通文本
            default:
                result = true;
                break;
        }
        return result;
    }

    /**
     * 根据传递过来的name参数，在指定表单范围内获取目标单选按钮组的值
     * @param  {jQuery|DOMElement} frm       表单容器
     * @param  {String} radiosName 单选按钮组的name属性
     * @return {String}            单选按钮组的值
     */
    function getRadioName(frm, radiosName)
    {
        var $frm = $(frm), $radios, result = "";
        $frm = $frm.length > 0 ? $frm : $(window);  //如果没有指定表单，则从全局查找
        $radios = $frm.find("input[type=radio][name=" + radiosName + "]")
        $radios.each(function(){
            var $ele = $(this);
            if($ele.prop("checked")){
                result = $ele.next().text();
                return false;
            }
        });
        return result;
    }
})(jQuery, undefined);




//========================================================================================================================================
//=============================================特殊处理-特殊处理==========================================================================
//=============================================特殊处理-特殊处理==========================================================================
//========================================================================================================================================
(function($, undefined){

    //特殊功能函数均开放全局访问权限
    $.extend(window, {

        /**
         * 老版本使用的GA接口，建议使用新的trackEvent函数代替使用
         */
        ggAnalytics: function()
        {
            trackEvent.apply(this, arguments);
        },

        /**
         * GA接口的封装
         * @param  {String} type    事件类型
         * @param  {String} operate 事件操作
         * @param  {String} label   事件标签
         * @return {undefined}
         */
        trackEvent: function(type, operate, label)
        {
            type = (type == undefined || type == 0) ? "Shangwutong" : type;
            operate = (operate == undefined || operate == 0) ? "\u6f02\u6d6e\u6846\u54a8\u8be2" : operate; //ASCII码字符：漂浮框咨询
            label = (label == undefined || label == 0) ? "zixun" : label;
            
            try
            {
                _gaq.push(['_trackEvent', type, type + "-" + operate, label]);
            }
            catch(e){}
            jQuery.post("/inc/ajax.ashx?act=addEventData&type=" + escape(type) + "&operate=" + escape(operate) + "&label=" + escape(label) + "&page=" + escape(location.href) + "&keywords=" + escape(jQuery.search_keywords) + "&source=" + escape(jQuery.search_source) + "&page_referrer=" + escape(document.referrer), function(){});
        },


        /**
         * QQ咨询（手机端的QQ咨询，需要较新版本的手机QQ才能支持）
         * @param  {String} num QQ号码，既可以是企业QQ也可以是个人QQ
         * @return {undefined}
         */
        qq: function(num)
        {
            var ua = navigator.userAgent, url;
            num = num || $$.qqNum;

            //匹配咨询URL
            if($.browser.isMobile){
                var QQReg = /QQ\/(\d+\.\d+)\.\d/i,
                    OldQQReg = /V1_AND_SQ_(\d+\.\d+)\.\d/i,
                    match = QQReg.exec(ua) || OldQQReg.exec(ua),
                    isQQ = !!match,
                    isQQUse = isQQ && /(?:4\.5|4\.6)/.test(match[1]), //在4.5、4.6的版本中需要使用本地协议的wpa类型来触发会话
                    wpaURL = "mqqwpa://im/chat?chat_type=wpa&uin=" + num + "&version=1&src_type=web&web_src=http://wpa.b.qq.com",   //较低版本的触发链接
                    crmURL = "mqqwpa://im/chat?chat_type=crm&uin=" + num + "&version=1&src_type=web&web_src=http://wpa.b.qq.com",   //较新版本的触发链接
                    start = +new Date();
                
                if(ua.indexOf("MicroMessenger") > -1){
                    location.href = /^(400|800)/.test(num) ? "http://wpd.b.qq.com/page/info.php?nameAccount=" + num : "http://wpa.qq.com/msgrd?v=3&uin=" + num + "&site=qq&menu=yes";  
                }else{
                    //通过手机QQ本地协议发起QQ会话，均适用于企业QQ和个人QQ（该方法将会直接开启会话，Android平台中QQ4.2不支持，4.3、4.4没有得到测试，QQ4.5则开始支持；而在iPhone平台中由于测试的对象都有及时更新QQ的习惯，所以视为完全支持来进行处理）
                    Extend.openInIframe(isQQUse ? wpaURL : crmURL);
                    !isQQ && setTimeout(function(){
                        if(+new Date() - start < 1000){
                            Extend.openInIframe(wpaURL); //延时低于1000视为触发失败，尝试使用低版本链接进行触发
                        };
                    }, 800);
                }
            }else{
                //企业QQ咨询：会提醒用户是否打开企业QQ进行咨询，然后触发本地协议进行对话
                //个人QQ咨询：直接通过本地协议进行对话，仅PC端支持，在某些浏览器中无需提醒即可对话
                switch(num)
                {
                    //对已知的企业QQ使用现有的本地协议进行咨询
                    case "800010082": //西安中大营销QQ
                    case "800077475": //上海沪申企业QQ
                        $.post("/inc/ajax.ashx?act=getQQ&qq=" + num, function(){
                            Extend.openInIframe(arguments[0]);
                        });
                        break;

                    default:
                        url = /^(400|800)/.test(num) ? 
                                "http://b.qq.com/webc.htm?new=0&sid=" + num + "&o=&q=7&from=qqwpa" :    //企业QQ咨询：会提醒用户是否打开企业QQ进行咨询
                                "tencent://message/?uin=" + num + "&Site=&Menu=yes";            //个人QQ咨询：本地协议，在某些浏览器中无需提醒即可对话
                        Extend.openInIframe(url);
                }
            }
        },

        /**
         * 打开“网络电话”页面
         * @param  {String} label 标签，用来标识是从哪个地方点击触发的
         * @return {undefined}
         */
        tel: function(label)
        {
            window.open("/tel.html" + (label === undefined ? "" : "?label=" + label), "_blank");
        },

        /**
         * 打开“预约挂号”页面
         * @param  {String} label 标签，用来标识是从哪个地方点击触发的
         * @return {undefined}
         */
        register: function(label)
        {
            var width = 649, height = 515, left = (screen.width - width) / 2;
            window.open("/register.html" + (label === undefined ? "" : "?label=" + label), "_blank", "width=" + width + ",height=" + height + ",top=200,left=" + left + ",status=yes,toolbar=no,menubar=no,resizable=no,scrollbars=no,location=no,titlebar=no");
        }

    });
})(jQuery, undefined);





//========================================================================================================================================
//=============================================商务通定义-商务通定义======================================================================
//=============================================商务通定义-商务通定义======================================================================
//========================================================================================================================================
(function(window, $, undefined){

    //==================================
    //通用变量声明
    var $def = $(),
        $oldCenter = $def,  //原邀请框
        $oldCenter2 = $def, //原邀请框内容容器
        $oldFloat = $def,   //原漂浮框

        id_zxCenter = "#zixunBox",      //自定义邀请框的ID
        id_zxAside = "#zixunBoxAside",  //自定义漂浮框d的ID

        oldDoCloseCenter = $.noop,   //原关闭邀请框的方法
        oldDoHideCenter = $.noop,    //原隐藏邀请框的方法
        oldDoCloseFloat = $.noop,    //原关闭漂浮框的方法

        pageLoaded = false,     //用来标识页面是否加载完成

        stopRewriteSWT,         //商务通函数重写程序的计时器ID
        stopCheckCenter = 0,    //邀请框监测程序的计时器ID
        stopCheckFloat = 0,     //漂浮框监测程序的计时器ID
        
        closeCenterTime = 0,      //关闭邀请框的次数
        hideCenterTime = 0;       //隐藏邀请框的次数

    window.float_zixunPage = false;         //页面是否即将被咨询页面覆盖
    window.float_showFirst = true;        //首次是否显示邀请框


    //==================================
    //商务通咨询行为的自定义
    //==================================
    //openZoosUrl方法的自定义版本（商务通直接对话）
    function rewriteZoosUrl()
    {
        var width = window.zixunWidth || 720,
            height = window.zixunHeight || 610,
            left = (screen.width - width) / 2,
            top = (screen.height - width) / 2,
            label = "?label=",
            url = "/zixun.aspx?" + "&cid=" + (window.LR_cid || "") + "&lng=" + (window.LR_lng || "") + "&sid=" + (window.LR_sid || "") + "&page=" + location.href + label + "openZoosUrl",
            oWindow;

        //使用float_zixunPage变量表示页面即将被咨询页面覆盖，可供其他功能需求做兼容处理
        //例如：网站中做了跳出提示的功能，而如果在最后一个网页中被启动直接咨询对话，那么在进入对话页面之前会提示用户是否退出当前页面。而如果在跳出提示代码实现中加入该变量的判断就可以避免这种情况
        window.float_zixunPage = true;
        setTimeout(function(){
            window.float_zixunPage = false;
        }, 3000);

        //首先使用window.open直接弹出，如果弹出失败则直接更改当前页面的URL
        oWindow = window.open(url, "_blank", "width=" + width + ",height=" + height + ",top=" + top + ",left=" + left + ",status=yes,toolbar=no,menubar=no,resizable=yes,scrollbars=no,location=no,titlebar=no");
        try{
            //在IE、Firefox、Chrome、Safari、傲游浏览器、世界之窗浏览器、搜狗浏览器中，oWindow的值为undefined
            //而在360安全浏览器、360极速浏览器、世界之窗浏览器中，oWindow则为有效的window对象
            oWindow.document.body.innerHTML === "" && location.assign(url);
        }catch(e){
            location.assign(url);
        }
        trackEvent("Shangwutong", "\u6f02\u6d6e\u6846\u54a8\u8be2", "openZoosUrl"); //ASCII码字符：漂浮框咨询
    }
    //zixun方法的自定义版本（统一跳转至zixun.aspx页面）
    function rewriteZixun(param, swt)
    {
        var width = window.zixunWidth || 720,
            height = window.zixunHeight || 610,
            left = (screen.width - width) / 2,
            top = (screen.height - width) / 2,
            hostname = location.hostname,
            label = "?label=",
            url = "/zixun.aspx?" + "&cid=" + (window.LR_cid || "") + "&lng=" + (window.LR_lng || "") + "&sid=" + (window.LR_sid || "") + "&page=" + location.href;
        
        if(swt){
            //例：zixun(0, 'floatRight-1');
            //表示为商务通邀请框或漂浮框的点击
            window.open(url+ label + swt, "_blank", "width=" + width + ",height=" + height + ",top=" + top + ",left=" + left + ",status=yes,toolbar=no,menubar=no,resizable=yes,scrollbars=no,location=no,titlebar=no");
            trackEvent("Shangwutong", "\u6f02\u6d6e\u6846\u54a8\u8be2", swt); //ASCII码字符：漂浮框咨询   
        }else{
            //例：zixun('header-btn1');
            //表示为站内咨询按钮或链接的点击
            param = param == undefined ? "zixun" : param;
            window.open(url+ label + param, "_blank", "width=" + width + ",height=" + height + ",top=" + top + ",left=" + left + ",status=yes,toolbar=no,menubar=no,resizable=yes,scrollbars=no,location=no,titlebar=no");
            trackEvent("Shangwutong", "\u7ad9\u5185\u54a8\u8be2", param);  //ASCII码字符：站内咨询
        }
    }
    //将上面两个自定义版本的函数作为默认的咨询方法
    window.zixun = $$.zixun = rewriteZixun;
    window.openZoosUrl = rewriteZoosUrl;


    //==================================
    //重写商务通的相关函数
    //==================================
    function rewriteSWT()
    {
        var isUseQiao = window.qiaoStr === "qiao.baidu.com";

        //如果zixun方法还没有被商务通统一接口重新赋值，则继续监测
        if(!pageLoaded && (isUseQiao ? $("#BDBridgeInviteWrap").length === 0 : $("#LRdiv1").length === 0)) return;
        clearInterval(stopRewriteSWT);

        //商务通统一接口加载完毕后，对zixun方法再次进行重新赋值
        if(isUseQiao)
        {
            //百度商桥重写配置
            //===================================
            $oldCenter = $("#BDBridgeInviteWrap");
            $oldCenter2 = $("#InviteContainer");
            $oldFloat = $("#BDBridgeIconWrap");
            oldDoCloseCenter = function(){
                try{ bridgeInviteClose(); } catch(e) {}  //反馈给百度商桥：关闭邀请框 + 拒绝邀请
            };
            oldDoHideCenter = function(){
                try{ BDBridge.invite.__hide();BDBridge.invite.__doClear() } catch(e) {}  //反馈给百度商桥：隐藏邀请框（如果处于邀请状态，则隔6秒还会继续弹出邀请框）
            };
            oldDoCloseFloat = function(){};  //百度商桥无关闭漂浮框行为

            //重置zixun方法
            window.zixun = function(){
                $("#chatnow").click();
            };
        }
        else
        {
            //商务通重写配置
            //===================================
            $oldCenter = $("#LRdiv1");
            $oldCenter2 = $();
            $oldFloat = $("#LRdiv0");
            oldDoCloseCenter = function(){
                try{ LR_HideInvite();LR_RefuseChat(); } catch(e) {}  //反馈给商务通：关闭邀请框 + 拒绝邀请
            };
            oldDoHideCenter = function(){
                try{ LR_HideInvite(); } catch(e) {}  //反馈给商务通：隐藏邀请框（如果处于邀请状态，则隔6秒还会继续弹出邀请框）
            };
            oldDoCloseFloat = function(){
                try{ onlinerIcon0.hidden(); } catch(e) {}  //反馈给商务通：关闭漂浮框
            };

            //监测百度商桥漂浮框，将其永久隐藏
            function checkBDBridge(){
                var $BDBridge = $("#BDBridgeIconWrap");
                if($BDBridge.length){
                    $BDBridge.add("#BDBridgeMess").add("#BDBridgeInviteWrap").css("cssText", ";display:none !important; visibility:hidden !important;");
                }else{
                    setTimeout(checkBDBridge, 100);
                }
            }
            checkBDBridge();

            //获取商务通咨询窗口的宽度和高度
            if(/width=(\d+)\,height=(\d+)\,/.exec(window.zixun.toString()) !== null){
                window.zixunWidth = RegExp.$1;
                window.zixunHeight = RegExp.$2;
            }

            //重置咨询方法
            window.zixun = rewriteZixun;
            setTimeout(function(){
                window.openZoosUrl = rewriteZoosUrl; //商务通中的openZoosUrl方法在zixun方法被重置时还没有被创建，这里通过延时执行来避免这个问题
            }, 5000);
        }

        //对23:30~08:00这段时间内没有咨询人员在线的情况进行兼容性处理
        jQuery.post("/inc/ajax.ashx?act=timeNow", function(){
            var timeNow = new Date(arguments[0]);  //服务器当前时间
            if((timeNow.getHours() >= 23 && timeNow.getMinutes() >= 30) || timeNow.getHours() < 8){
                window.zixun = $$.zixun; //如果网站项目的脚本配置中具备$$.zixun的重新赋值，则采用该网站自定义的zixun需求
            }
        });

        //对原有邀请框和漂浮框进行隐藏预处理
        $oldCenter.css("cssText", ";visibility:hidden !important;"); 
        $oldCenter2.css("cssText", ";display:none !important; visibility:hidden !important;"); 
        $oldFloat.css("cssText", ";visibility:hidden !important;"); 

        //开始监测行为
        stopCheckCenter = setInterval(checkCenterChange, 100);
        stopCheckFloat = setInterval(checkFloatChange, 100);
    }
    stopRewriteSWT = setInterval(rewriteSWT, 100);

    
    //==================================
    //邀请框行为的自定义
    //==================================

    //自定义邀请框/漂浮框的显示与隐藏
    $.extend(window, {
        zxCenter_show: function(){
            $(id_zxCenter).show();
        },
        zxCenter_hide: function(){
            $(id_zxCenter).hide();
        },
        zxAside_show: function(){
            $(id_zxAside).show();
        },
        zxAside_hide: function(){
            $(id_zxAside).hide();
        }
    });

    //执行邀请框的显示处理
    function execCenterShow()
    {
        if($(id_zxCenter).length){
            window.zxAside_hide();
            window.zxCenter_show();
        }else{
            window.zxAside_show();
        }
    }

    //执行邀请框的隐藏处理
    function execCenterHide()
    {
        window.zxCenter_hide();
        window.zxAside_show();
    }

    //邀请框的监测程序
    function checkCenterChange()
    {
        if(!$oldCenter.is(":visible")) return;  //这里不能使用:hidden判断，因为在没有元素时:hidden的返回结果也为false

        var isHideForever = window.float_hideMode === "1";  //永久隐藏，不可邀请
        var isHideFirst = window.float_hideMode === "2";    //首次隐藏，可以邀请
        var $zxCenter = $(id_zxCenter);

        //隐藏原邀请框并判断是否显示自定义的邀请框
        $oldCenter.hide();
        if($zxCenter.length){
            //首先通过邀请框显示模式进行判断
            //再次通过是否首次显示邀请框来进行判断
            if(!isHideForever && (!isHideFirst || hideCenterTime >= 1) || (window.float_showFirst && hideCenterTime === 0)){
                execCenterShow();
            }
        }

        //如果模式为“首次隐藏，可以邀请”，则在首次显示邀请框时将关闭状态值设置为1
        if(isHideFirst && hideCenterTime === 0){
            hideCenterTime = 1;
        }

        //如果没有自定义邀请框或者永久隐藏邀请框，则执行一次关闭邀请框动作
        (!$zxCenter.length || isHideForever) && oldDoCloseCenter(); 
    }

    //漂浮框的监测程序
    function checkFloatChange()
    {
        if($oldFloat.is(":visible")){
            $oldFloat.hide();
        }
    }

    //隐藏邀请框（对外可访问）
    window.float_hideCenter = function(isClose)
    {
        execCenterHide();
        oldDoHideCenter();
        hideCenterTime++;
    };

    //关闭邀请框（对外可访问）
    window.float_closeCenter = function()
    {
        execCenterHide();
        oldDoCloseCenter();
        hideCenterTime++;
        closeCenterTime++;
        window.float_doOnCloseCenter && window.float_doOnCloseCenter();
    };

    //隐藏漂浮框（对外可访问）
    window.float_hideFloat = function()
    {
        oldDoCloseFloat();
        window.zxAside_hide();
    };

    //==========================
    //真个文档加载完毕之后，执行相关检测
    //==========================
    $(window).on("load", function()
    {
        pageLoaded = true;

        //如果还没有商务通的默认容器，则直接显示邀请框
        if($oldCenter.length === 0){
            execCenterShow();
            clearInterval(stopCheckCenter);
            clearInterval(stopCheckFloat);
        }
        //如果邀请框没有被关闭一次，且允许首次显示邀请框，则执行显示邀请框操作
        //DOM加载完毕以及整个文档加载完毕均执行一次检测
        else if(window.float_showFirst && hideCenterTime === 0){
            execCenterShow();
        }
    });

    //==========================
    //DOM加载完毕后执行相关配置操作
    //==========================
    $(function()
    {
        //如果邀请框没有被关闭一次，且允许首次显示邀请框，则执行显示邀请框操作
        //DOM加载完毕以及整个文档加载完毕均执行一次检测
        if(window.float_showFirst && hideCenterTime === 0){
            execCenterShow();
        }

        // ==========================
        // 关于商务通邀请框的特殊设置：
        // 1. 默认情况下，邀请框允许被邀请，网页中邀请框的显示将由咨询人员的邀请行为决定。
        // 2. 当晚上10点过后，以及早上8点之前，由于时间和心理因素，咨询人员的邀请行为会在不知不觉中放缓，因此在这个时间段内将设置为不可邀请，同时在网页中每间隔5秒会自动弹出邀请框一次。
        // ===============================================================================
        if($$.siteName === "xian"){
            window.float_bindEffect("fade");    //绑定淡入淡出的邀请框效果
            window.float_hideMode = undefined;  //不隐藏邀请框，咨询人员可邀请
            jQuery.post("/inc/ajax.ashx?act=timeNow", function(){                
                var timeNow = new Date(arguments[0]);  //服务器当前时间
                if(timeNow.getHours() >= 22 || timeNow.getHours() < 8){
                    window.float_hideMode = "1"; //邀请框永久隐藏，不允许咨询进行邀请操作
                    window.float_doOnCloseCenter = function(){
                        setTimeout(execCenterShow, 5000);
                    }
                }
            });
        }
        // ==========================
        // 关于商务通邀请框的特殊设置：
        // 1. 在用户进入网页后禁止咨询人员邀请访客，即使邀请也将属于无效操作；
        // 2. 邀请框大概在网站打开后的3~5秒内弹出一次；
        // 3. 当访客首次关闭邀请框后，间隔30秒将再次自动弹出；
        // 4. 当访客再次关闭邀请框后，将不再自动弹出，咨询人员将恢复邀请访客的权限；
        // ========================================================================
        else if($$.siteName === "hushen"){
            window.float_bindEffect("zoom");    //绑定缩放的邀请框效果
            window.float_hideMode = "1";        //邀请框永久隐藏，不允许咨询进行邀请操作
            window.float_doOnCloseCenter = function(){

                //邀请框关闭两次之后，恢复为普通模式
                if(closeCenterTime > 1){
                    window.float_hideMode = undefined;
                    window.float_doOnCloseCenter = undefined;
                    return;
                }

                //邀请框自动弹出
                setTimeout(execCenterShow, 30000);
            };
        }
    });

    //==========================
    //绑定商务通邀请框、邀请框的动画效果
    //==========================
    window.float_bindEffect = function(effect)
    {
        switch(effect)
        {
            //淡入淡出效果
            case "fade":
            
                jQuery.extend(window, {
                    zxCenter_show: function(){
                        $(id_zxAside).hide();
                        $(id_zxCenter).fadeIn();
                    },
                    zxCenter_hide: function(){
                        $(id_zxCenter).fadeOut(function(){
                            $(id_zxAside).fadeIn();
                        });
                    },
                    zxAside_show: $.noop,
                    zxAside_hide: function(){
                        $(id_zxAside).fadeOut();
                    }
                });
                break;
                           
            //缩放效果
            case "zoom":
            
                jQuery.extend(window, {
                    zxCenter_show: function(){
                        $(id_zxAside).hide();
                        $(id_zxCenter).fadeIn(500).css("transform", "scale(1, 1)");
                    },
                    zxCenter_hide: function(){
                        $(id_zxCenter).css("transition", "all 0.5s linear").css("transform", "scale(0, 0)").fadeOut(500, function(){
                            $(id_zxAside).fadeIn();
                        });
                    },
                    zxAside_show: $.noop,
                    zxAside_hide: function(){
                        $(id_zxAside).fadeOut();
                    }
                });
                break;
                
            //移动效果
            case "move":

                jQuery.extend(window, {
                    zxCenter_show: function(){
                        $(id_zxAside).hide();
                        $(id_zxCenter).fadeIn();
                    },
                    zxCenter_hide: function(){

                        var $zxCenter = $(id_zxCenter),
                            $zxAside = $(id_zxAside),
                            cssAnimate = $zxCenter.data("cssAnimate"),
                            cssDefault = $zxCenter.data("cssDefault");

                        if(cssAnimate === undefined)
                        {
                            //没有漂浮框或者在IE6下则使用缩放效果代替
                            if($zxAside.length === 0 || $.browser.isIE6){
                                window.float_bindEffect("zoom");
                                return;
                            }
                            
                            //方向的定位
                            var directX = $zxAside.css("left") === "auto" ? "right" : "left",
                                directY = $zxAside.css("top") === "auto" ? "bottom" : "top",
                                marginX = "margin-" + directX,
                                marginY = "margin-" + directY;             
                            
                            //邀请框的默认位置
                            cssDefault = {
                                width: $zxCenter.width(),
                                height: $zxCenter.height(),
                                opacity: 1
                            };
                            cssDefault[directX] = $zxCenter.css(directX);
                            cssDefault[directY] = $zxCenter.css(directY);
                            cssDefault[marginX] = parseInt($zxCenter.css(marginX));
                            cssDefault[marginY] = parseInt($zxCenter.css(marginY));
                            
                            //邀请框的动画位置
                            cssAnimate = {
                                width: 0,
                                height: 0,
                                opacity: 0.2
                            };
                            cssAnimate[directX] = $zxAside.css(directX);
                            cssAnimate[directY] = $zxAside.css(directY);
                            cssAnimate[marginX] = 0;
                            cssAnimate[marginY] = 0;

                            $zxCenter.data({cssDefault: cssDefault, cssAnimate: cssAnimate});
                        }

                        $zxCenter.animate(cssAnimate, 1000, "easeOutSine", function(){
                            $zxCenter.css(cssDefault).hide();
                            $zxAside.fadeIn();
                        });
                    },
                    zxAside_show: $.noop,
                    zxAside_hide: function(){
                        $(id_zxAside).fadeOut();
                    }
                });
                break;
        }
    };
})(window, jQuery, undefined);